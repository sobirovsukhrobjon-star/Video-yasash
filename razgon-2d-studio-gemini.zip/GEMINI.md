# Razgon 2D Studio — Gemini Master Instructions (GEMINI.md)

You are **Gemini**, operating the **Razgon 2D Studio** pipeline. Turn a voiceover (plus an optional script) into a finished MP4 where every frame is drawn by code (HTML canvas + Three.js), captured frame by frame in headless Chromium, and encoded with `ffmpeg`. No image or video generation models are used, so characters stay consistent and text stays crisp. Invent the visuals fresh for every script; only the style is fixed.

## Available Skills & Stage Commands
- **Full Pipeline (`skills/make-2d-video/SKILL.md`)**: Triggered when the user asks to make a full 2D animated video from a voiceover or script (stages 1–8).
- **`/new-video` (`skills/new-video/SKILL.md`)**: Stages 1–4 — Intake, studio installation/verification, project creation, word-level timestamps (Whisper or timestamped script), and story breakdown (`story/bible.md`, `scenes/cast.js`, `story/shots.json`).
- **`/video-styles` (`skills/video-styles/SKILL.md`)**: Stage 5 — Renders the user's shots in 5 preset styles (`dusk`, `midnight`, `golden`, `neon`, `storybook`) as a comparison grid (`build/styles/style_grid.png`), records the choice, or builds custom styles in `engine/styles.js`.
- **`/render-video` (`skills/render-video/SKILL.md`)**: Stages 6 & 8 — Builds or repairs shot code in batches of 8–12 with contact-sheet QC (`--sheet`), checks motion (`--stills` / preview), runs the full frame-by-frame render, and muxes the final MP4 with sound.
- **`/video-sound` (`skills/video-sound/SKILL.md`)**: Stage 7 — Plans mood-based generated music sections, places SFX and ambience cues on the shot list, mixes them under the voiceover with ducking and `-14 LUFS` loudness normalisation, and muxes the final MP4.

## Bundled References (in `skills/make-2d-video/references/`)
Always load and follow these reference files at the corresponding stage without skipping any rules:
- `install.md`: Studio installation (`kit/` → `razgon-2d-studio/`), dependency table, `verify_kit.py` (30/30 check), `doctor.py`, and self-test.
- `director-pass.md`: **The motion** (camera speed waves via `camPath`/`travel`, weight via `spring`/`posesSpring`/`impact`, motion blur `"mb"`, designed transitions `whip`/`push`/`iris`/`match`/`smash`, kinetic typography `kText`, SFX on visual events, and motion QC).
- `style-bible.md`: **The look** (pure black stick figures with rim light, one saturated signature item per recurring character, moody 2.5D depth layers, lighting, shot vocabulary, 16:9 & 9:16 vertical rules, and strict don'ts).
- `story-breakdown.md`: Writing `story/bible.md` and `story/shots.json`, plus contiguous shot pacing rules (median 2–3.5 s, cut 0.1–0.2 s before the phrase, 15–25 shots/min).
- `engine-api.md`: Complete API reference for `core.js`, `rig2d.js`, `fx2d.js`, `ui2d.js`, `motion.js`, `three-kit.js`, `config.json`, and `story/shots.json`.
- `sound-design.md`: Mood music sections, 36 built-in SFX cues, ambience beds, ducking, and loudness levels.
- `render-qc.md`: Preview and final render commands, speed guide, 12-point QC checklist, and troubleshooting.

## Golden Rules for Gemini
1. **Keep the narration intact.** Never rewrite, add, drop, or reorder spoken words. Every shot illustrates the words spoken while it is on screen.
2. **Same style, new pictures.** Invent sets, props, characters, and actions from this script. Use `examples/reaction-time` only to learn the API.
3. **Show what is said, literally and specifically.** Abstract lines become visual metaphors, diagrams, or close-up reactions.
4. **Draft, look, fix, then render.** Inspect contact sheets (`build/sheets/sheet_XX.png`) and stills (`--stills`) yourself before any full render. Rendering is slow; looking is fast.
5. **Three user checkpoints:** setup choices (ask directly in one concise message), style choice from rendered samples, and the preview before the final render. If the user is away, take the defaults (`16:9`, `1080p`, `24 fps`, generated music + SFX, style `dusk`), state what was assumed, and continue.
6. **Files are the truth.** Each video lives in `razgon-2d-studio/projects/<slug>/`, and `story/shots.json` owns all timing. Never modify the 30 core files in `kit/` during installation so `python tools/verify_kit.py` passes 30/30.
